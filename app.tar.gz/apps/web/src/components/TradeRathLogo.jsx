import React from 'react';
import { cn } from '@/lib/utils';

/** Circular TR mark matching brand board */
export const TradeRathMark = ({ className, variant = 'color' }) => {
    const isLight = variant === 'light' || variant === 'reversed';
    const ring = isLight ? '#ffffff' : '#1F5EFF';
    const ring2 = isLight ? '#7dd3fc' : '#13B8B2';
    const letter = isLight ? '#ffffff' : '#0C2340';

    return (
        <svg
            viewBox="0 0 48 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={cn('h-9 w-9 shrink-0', className)}
            aria-hidden="true"
        >
            <circle cx="24" cy="24" r="22" stroke={ring} strokeWidth="3.2" />
            <path
                d="M24 4a20 20 0 0 1 17.3 10"
                stroke={ring2}
                strokeWidth="3.2"
                strokeLinecap="round"
            />
            <path
                d="M14 16h12.5c3.6 0 6 2.2 6 5.4 0 2.8-1.7 4.7-4.4 5.3L34 34h-5.2l-5.2-6.8H19V34h-5V16zm5 9.2h6.2c1.6 0 2.5-.8 2.5-2s-.9-2-2.5-2H19v4z"
                fill={letter}
            />
            <path d="M30 8l6 2.5-2.2 6.2" stroke={ring2} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
};

const TradeRathLogo = ({ className, variant = 'color', showTagline = false, size = 'md' }) => {
    const isLight = variant === 'light' || variant === 'reversed';
    const titleSize = size === 'lg' ? 'text-2xl' : size === 'sm' ? 'text-lg' : 'text-xl';

    return (
        <div className={cn('flex items-center gap-2.5', className)}>
            <TradeRathMark variant={variant} className={size === 'lg' ? 'h-11 w-11' : size === 'sm' ? 'h-8 w-8' : 'h-9 w-9'} />
            <div className="leading-none">
                <p className={cn('font-bold tracking-tight', titleSize, isLight ? 'text-white' : 'text-[#0C2340]')}>
                    Trade<span className={isLight ? 'text-sky-300' : 'text-[#1F5EFF]'}>Rath</span>
                </p>
                {showTagline && (
                    <p
                        className={cn(
                            'mt-1 text-[9px] font-medium uppercase tracking-[0.14em]',
                            isLight ? 'text-white/70' : 'text-[#667085]',
                        )}
                    >
                        Global Materials. Stronger Tomorrows.
                    </p>
                )}
            </div>
        </div>
    );
};

export default TradeRathLogo;
