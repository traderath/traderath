import React, { useState } from 'react';
import { ArrowRight, ChevronDown, Globe2, Menu, Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import TradeRathLogo from '@/components/TradeRathLogo';

const NAV_LINKS = [
    { label: 'Solutions', href: '#services', hasMenu: true },
    { label: 'Materials', href: '#materials', hasMenu: true },
    { label: 'Global Network', href: '#network' },
    { label: 'About', href: '#about' },
    { label: 'Resources', href: '#process', hasMenu: true },
    { label: 'Contact', href: '#contact' },
];

const SiteHeader = () => {
    const [open, setOpen] = useState(false);

    return (
        <header className="sticky top-0 z-50 border-b border-[#e8eef5] bg-white/95 backdrop-blur-md">
            <div className="tr-container flex h-[72px] items-center justify-between gap-4">
                <a href="#top" className="shrink-0" aria-label="TradeRath home">
                    <TradeRathLogo showTagline size="sm" />
                </a>

                <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary">
                    {NAV_LINKS.map((link) => (
                        <a
                            key={link.label}
                            href={link.href}
                            className="inline-flex items-center gap-1 text-[14px] font-medium text-[#0C2340]/80 transition-colors hover:text-[#1F5EFF]"
                        >
                            {link.label}
                            {link.hasMenu && <ChevronDown className="h-3.5 w-3.5 opacity-60" />}
                        </a>
                    ))}
                </nav>

                <div className="flex items-center gap-2 sm:gap-3">
                    <button
                        type="button"
                        className="hidden h-10 w-10 items-center justify-center rounded-full text-[#667085] transition-colors hover:bg-[#F7F9FC] xl:inline-flex"
                        aria-label="Search"
                    >
                        <Search className="h-4.5 w-4.5" />
                    </button>
                    <a
                        href="#contact"
                        className="hidden items-center rounded-full border border-[#d0d7e2] px-4 py-2 text-sm font-semibold text-[#0C2340] transition-colors hover:border-[#1F5EFF] hover:text-[#1F5EFF] md:inline-flex"
                    >
                        Request a Quote
                    </a>
                    <a
                        href="/login"
                        className="group hidden items-center gap-1.5 rounded-full bg-[#1F5EFF] px-4 py-2 text-sm font-semibold text-white shadow-sm shadow-blue-600/25 transition-all hover:bg-[#1749d6] md:inline-flex"
                    >
                        Get Started
                        <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                    </a>
                    <button
                        type="button"
                        className="hidden items-center gap-1.5 rounded-full px-2 py-2 text-sm font-medium text-[#667085] lg:inline-flex"
                        aria-label="Language"
                    >
                        <Globe2 className="h-4 w-4" />
                        EN
                        <ChevronDown className="h-3 w-3" />
                    </button>
                    <button
                        type="button"
                        onClick={() => setOpen((v) => !v)}
                        className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[#e8eef5] text-[#0C2340] lg:hidden"
                        aria-label={open ? 'Close menu' : 'Open menu'}
                        aria-expanded={open}
                    >
                        {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                    </button>
                </div>
            </div>

            <div
                className={cn(
                    'overflow-hidden border-t border-[#e8eef5] bg-white transition-[max-height] duration-300 ease-out lg:hidden',
                    open ? 'max-h-[480px]' : 'max-h-0 border-t-0',
                )}
            >
                <nav className="flex flex-col px-5 py-3" aria-label="Mobile">
                    {NAV_LINKS.map((link) => (
                        <a
                            key={link.label}
                            href={link.href}
                            onClick={() => setOpen(false)}
                            className="border-b border-[#e8eef5] py-3 text-sm font-medium text-[#0C2340]"
                        >
                            {link.label}
                        </a>
                    ))}
                    <a
                        href="#contact"
                        onClick={() => setOpen(false)}
                        className="mt-3 rounded-full border border-[#d0d7e2] px-4 py-3 text-center text-sm font-semibold text-[#0C2340]"
                    >
                        Request a Quote
                    </a>
                    <a
                        href="/login"
                        onClick={() => setOpen(false)}
                        className="mt-2 rounded-full bg-[#1F5EFF] px-4 py-3 text-center text-sm font-semibold text-white"
                    >
                        Get Started
                    </a>
                </nav>
            </div>
        </header>
    );
};

export default SiteHeader;
